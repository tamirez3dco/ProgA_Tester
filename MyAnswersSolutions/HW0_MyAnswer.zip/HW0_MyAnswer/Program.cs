﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW0_MyAnswer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("029046117");
            Console.WriteLine("** 029046117 **");
            Console.WriteLine();
            Console.WriteLine("   **   ");
            Console.WriteLine("  *  *  ");
            Console.WriteLine(" *    * ");
            Console.WriteLine("*      *");
            Console.WriteLine("*      *");
            Console.WriteLine(" *    * ");
            Console.WriteLine("  *  *  ");
            Console.WriteLine("   **   ");
            String str1 = Console.ReadLine();
            Console.WriteLine("===");
            Console.WriteLine("{0}",str1);
            Console.WriteLine(" {0}", str1);
            Console.WriteLine("  {0}", str1);
            Console.WriteLine("   {0}", str1);
            Console.WriteLine("    {0}", str1);
            Console.WriteLine("     {0}", str1);
            Console.WriteLine("    {0}", str1);
            Console.WriteLine("   {0}", str1);
            Console.WriteLine("  {0}", str1);
            Console.WriteLine(" {0}", str1);
            Console.WriteLine("{0}", str1);
            String str2 = Console.ReadLine();
            Console.WriteLine("{0} {1}", str1, str2);
            Console.WriteLine("{0} {1}", str2, str1);

        }
    }
}
